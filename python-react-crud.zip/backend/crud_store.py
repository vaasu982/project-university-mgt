items = []
item_id_counter = 1

def list_items():
    return items

def create_item(name):
    global item_id_counter
    item = {"id": item_id_counter, "name": name}
    items.append(item)
    item_id_counter += 1
    return item

def update_item(item_id, new_name):
    for item in items:
        if item["id"] == item_id:
            item["name"] = new_name
            return item
    return None

def delete_item(item_id):
    global items
    items = [item for item in items if item["id"] != item_id]
