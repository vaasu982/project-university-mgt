from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import crud_store

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

class Item(BaseModel):
    name: str

class ItemUpdate(BaseModel):
    name: str

@app.get("/items")
def get_items():
    return crud_store.list_items()

@app.post("/items")
def add_item(item: Item):
    return crud_store.create_item(item.name)

@app.put("/items/{item_id}")
def update_item(item_id: int, item: ItemUpdate):
    updated = crud_store.update_item(item_id, item.name)
    if updated:
        return updated
    raise HTTPException(status_code=404, detail="Item not found")

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    crud_store.delete_item(item_id)
    return {"message": "Item deleted"}
