import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [items, setItems] = useState([]);
  const [newName, setNewName] = useState("");
  const [editId, setEditId] = useState(null);

  const fetchItems = async () => {
    const res = await fetch("http://localhost:8000/items");
    setItems(await res.json());
  };

  const addItem = async () => {
    await fetch("http://localhost:8000/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName })
    });
    setNewName("");
    fetchItems();
  };

  const updateItem = async (id) => {
    await fetch(`http://localhost:8000/items/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName })
    });
    setEditId(null);
    setNewName("");
    fetchItems();
  };

  const deleteItem = async (id) => {
    await fetch(`http://localhost:8000/items/${id}`, { method: "DELETE" });
    fetchItems();
  };

  useEffect(() => {
    fetchItems();
  }, []);

  return (
    <div className="App">
      <h1>Simple CRUD</h1>
      <input
        value={newName}
        onChange={(e) => setNewName(e.target.value)}
        placeholder="Item name"
      />
      <button onClick={editId ? () => updateItem(editId) : addItem}>
        {editId ? "Update" : "Add"}
      </button>

      <ul>
        {items.map(item => (
          <li key={item.id}>
            {item.name}
            <button onClick={() => {
              setEditId(item.id);
              setNewName(item.name);
            }}>Edit</button>
            <button onClick={() => deleteItem(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
